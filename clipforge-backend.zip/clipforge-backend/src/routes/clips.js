const express = require('express');
const router = express.Router();
const path = require('path');
const fs = require('fs');
const { jobs } = require('./video');

/**
 * GET /api/clips/:jobId
 * Returns clips array with file paths, metadata, virality scores
 */
router.get('/:jobId', (req, res) => {
  const job = jobs[req.params.jobId];
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json({
    jobId: req.params.jobId,
    status: job.status,
    progress: job.progress,
    clips: job.clips,
    error: job.error,
  });
});

/**
 * GET /api/clips/:jobId/:clipIndex/download
 * Streams clip file to client
 */
router.get('/:jobId/:clipIndex/download', (req, res) => {
  const job = jobs[req.params.jobId];
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const clip = job.clips[Number(req.params.clipIndex)];
  if (!clip) return res.status(404).json({ error: 'Clip not found' });

  if (!fs.existsSync(clip.filePath)) {
    return res.status(404).json({ error: 'Clip file not found on disk' });
  }

  res.download(clip.filePath, `clip_${req.params.clipIndex + 1}.mp4`);
});

module.exports = router;
