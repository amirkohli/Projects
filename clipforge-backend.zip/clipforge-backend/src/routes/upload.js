const express = require('express');
const router = express.Router();
const { jobs } = require('./video');
const { logger } = require('../utils/logger');

const youtubeService   = require('../services/platforms/youtube');
const instagramService = require('../services/platforms/instagram');
const facebookService  = require('../services/platforms/facebook');
const tiktokService    = require('../services/platforms/tiktok');
const twitterService   = require('../services/platforms/twitter');
const linkedinService  = require('../services/platforms/linkedin');
const snapchatService  = require('../services/platforms/snapchat');

const PLATFORM_SERVICES = {
  youtube:   youtubeService,
  instagram: instagramService,
  facebook:  facebookService,
  tiktok:    tiktokService,
  twitter:   twitterService,
  linkedin:  linkedinService,
  snapchat:  snapchatService,
};

/**
 * POST /api/upload/:platform
 * Body: { jobId, clipIndex, caption, scheduleAt? }
 * Uploads a single clip to the specified platform.
 */
router.post('/:platform', async (req, res) => {
  const { platform } = req.params;
  const { jobId, clipIndex, caption = '', scheduleAt } = req.body;

  const service = PLATFORM_SERVICES[platform.toLowerCase()];
  if (!service) {
    return res.status(400).json({ error: `Unknown platform: ${platform}` });
  }

  const job = jobs[jobId];
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const clip = job.clips[Number(clipIndex)];
  if (!clip) return res.status(404).json({ error: 'Clip index out of range' });

  logger.info('Upload requested', { platform, jobId, clipIndex });

  try {
    const result = await service.upload({ clip, caption, scheduleAt });
    logger.info('Upload success', { platform, postId: result.postId });
    res.json({ success: true, platform, postId: result.postId, url: result.url });
  } catch (err) {
    logger.error('Upload failed', { platform, err: err.message });
    res.status(500).json({ error: err.message });
  }
});

/**
 * POST /api/upload/all
 * Body: { jobId, clipIndex, platforms: ['youtube','tiktok',...], caption }
 * Uploads one clip to multiple platforms concurrently.
 */
router.post('/bulk/all', async (req, res) => {
  const { jobId, clipIndex, platforms = [], caption = '' } = req.body;

  const job = jobs[jobId];
  if (!job) return res.status(404).json({ error: 'Job not found' });

  const clip = job.clips[Number(clipIndex)];
  if (!clip) return res.status(404).json({ error: 'Clip not found' });

  const results = await Promise.allSettled(
    platforms.map(platform => {
      const svc = PLATFORM_SERVICES[platform.toLowerCase()];
      if (!svc) return Promise.reject(new Error(`Unknown platform: ${platform}`));
      return svc.upload({ clip, caption }).then(r => ({ platform, ...r }));
    })
  );

  const response = results.map((r, i) =>
    r.status === 'fulfilled'
      ? { platform: platforms[i], success: true, ...r.value }
      : { platform: platforms[i], success: false, error: r.reason.message }
  );

  res.json({ results: response });
});

module.exports = router;
