const express = require('express');
const router = express.Router();
const axios = require('axios');
const { google } = require('googleapis');
const { logger } = require('../utils/logger');

// ── YouTube / Google ───────────────────────────────────────
router.get('/youtube', (req, res) => {
  const oauth2Client = new google.auth.OAuth2(
    process.env.YOUTUBE_CLIENT_ID,
    process.env.YOUTUBE_CLIENT_SECRET,
    process.env.YOUTUBE_REDIRECT_URI
  );
  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    scope: ['https://www.googleapis.com/auth/youtube.upload'],
  });
  res.redirect(url);
});

router.get('/youtube/callback', async (req, res) => {
  const { code } = req.query;
  const oauth2Client = new google.auth.OAuth2(
    process.env.YOUTUBE_CLIENT_ID,
    process.env.YOUTUBE_CLIENT_SECRET,
    process.env.YOUTUBE_REDIRECT_URI
  );
  const { tokens } = await oauth2Client.getToken(code);
  logger.info('YouTube tokens received', { expiry: tokens.expiry_date });
  // Store tokens in DB in production; returning here for demo
  res.json({ message: 'YouTube connected!', tokens });
});

// ── Meta (Instagram + Facebook) ───────────────────────────
router.get('/meta', (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.META_APP_ID,
    redirect_uri: process.env.META_REDIRECT_URI,
    scope: 'pages_show_list,instagram_basic,instagram_content_publish,pages_manage_posts',
    response_type: 'code',
  });
  res.redirect(`https://www.facebook.com/v18.0/dialog/oauth?${params}`);
});

router.get('/meta/callback', async (req, res) => {
  const { code } = req.query;
  const { data } = await axios.get('https://graph.facebook.com/v18.0/oauth/access_token', {
    params: {
      client_id: process.env.META_APP_ID,
      client_secret: process.env.META_APP_SECRET,
      redirect_uri: process.env.META_REDIRECT_URI,
      code,
    },
  });
  logger.info('Meta token received');
  res.json({ message: 'Instagram & Facebook connected!', access_token: data.access_token });
});

// ── TikTok ────────────────────────────────────────────────
router.get('/tiktok', (req, res) => {
  const params = new URLSearchParams({
    client_key: process.env.TIKTOK_CLIENT_KEY,
    redirect_uri: process.env.TIKTOK_REDIRECT_URI,
    scope: 'video.upload',
    response_type: 'code',
    state: 'clipforge',
  });
  res.redirect(`https://www.tiktok.com/auth/authorize/?${params}`);
});

router.get('/tiktok/callback', async (req, res) => {
  const { code } = req.query;
  const { data } = await axios.post('https://open-api.tiktok.com/oauth/access_token/', {
    client_key: process.env.TIKTOK_CLIENT_KEY,
    client_secret: process.env.TIKTOK_CLIENT_SECRET,
    code,
    grant_type: 'authorization_code',
  });
  logger.info('TikTok token received');
  res.json({ message: 'TikTok connected!', data: data.data });
});

// ── Twitter / X ───────────────────────────────────────────
// Twitter OAuth 2.0 PKCE
router.get('/twitter', (req, res) => {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: process.env.TWITTER_API_KEY,
    redirect_uri: 'http://localhost:3000/auth/twitter/callback',
    scope: 'tweet.write users.read offline.access',
    state: 'clipforge',
    code_challenge: 'challenge',
    code_challenge_method: 'plain',
  });
  res.redirect(`https://twitter.com/i/oauth2/authorize?${params}`);
});

router.get('/twitter/callback', async (req, res) => {
  const { code } = req.query;
  const { data } = await axios.post(
    'https://api.twitter.com/2/oauth2/token',
    new URLSearchParams({
      code,
      grant_type: 'authorization_code',
      redirect_uri: 'http://localhost:3000/auth/twitter/callback',
      code_verifier: 'challenge',
    }),
    {
      auth: { username: process.env.TWITTER_API_KEY, password: process.env.TWITTER_API_SECRET },
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    }
  );
  logger.info('Twitter token received');
  res.json({ message: 'Twitter/X connected!', data });
});

// ── LinkedIn ──────────────────────────────────────────────
router.get('/linkedin', (req, res) => {
  const params = new URLSearchParams({
    response_type: 'code',
    client_id: process.env.LINKEDIN_CLIENT_ID,
    redirect_uri: process.env.LINKEDIN_REDIRECT_URI,
    scope: 'r_liteprofile w_member_social',
    state: 'clipforge',
  });
  res.redirect(`https://www.linkedin.com/oauth/v2/authorization?${params}`);
});

router.get('/linkedin/callback', async (req, res) => {
  const { code } = req.query;
  const { data } = await axios.post('https://www.linkedin.com/oauth/v2/accessToken',
    new URLSearchParams({
      grant_type: 'authorization_code',
      code,
      redirect_uri: process.env.LINKEDIN_REDIRECT_URI,
      client_id: process.env.LINKEDIN_CLIENT_ID,
      client_secret: process.env.LINKEDIN_CLIENT_SECRET,
    }),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
  );
  logger.info('LinkedIn token received');
  res.json({ message: 'LinkedIn connected!', data });
});

// ── Snapchat ──────────────────────────────────────────────
router.get('/snapchat', (req, res) => {
  const params = new URLSearchParams({
    client_id: process.env.SNAPCHAT_CLIENT_ID,
    redirect_uri: process.env.SNAPCHAT_REDIRECT_URI,
    response_type: 'code',
    scope: 'snapchat-marketing-api',
    state: 'clipforge',
  });
  res.redirect(`https://accounts.snapchat.com/login/oauth2/authorize?${params}`);
});

router.get('/snapchat/callback', async (req, res) => {
  const { code } = req.query;
  const { data } = await axios.post('https://accounts.snapchat.com/login/oauth2/access_token',
    new URLSearchParams({
      client_id: process.env.SNAPCHAT_CLIENT_ID,
      client_secret: process.env.SNAPCHAT_CLIENT_SECRET,
      code,
      grant_type: 'authorization_code',
      redirect_uri: process.env.SNAPCHAT_REDIRECT_URI,
    }),
    { headers: { 'Content-Type': 'application/x-www-form-urlencoded' } }
  );
  logger.info('Snapchat token received');
  res.json({ message: 'Snapchat connected!', data });
});

module.exports = router;
