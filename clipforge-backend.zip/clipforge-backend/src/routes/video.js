const express = require('express');
const router = express.Router();
const { v4: uuidv4 } = require('uuid');
const { analyzeVideo } = require('../services/videoAnalyzer');
const { logger } = require('../utils/logger');

// In-memory job store (swap for Redis in production)
const jobs = {};

/**
 * POST /api/video/analyze
 * Body: { url, clipLength, clipCount, format }
 * Returns: { jobId } — poll GET /api/clips/:jobId for results
 */
router.post('/analyze', async (req, res) => {
  const { url, clipLength = 60, clipCount = 5, format = '9:16' } = req.body;

  if (!url) return res.status(400).json({ error: 'url is required' });

  const jobId = uuidv4();
  jobs[jobId] = { status: 'queued', progress: 0, clips: [], error: null };

  // Run async – client polls for status
  analyzeVideo({ url, clipLength: Number(clipLength), clipCount: Number(clipCount), format, jobId, jobs })
    .catch(err => {
      logger.error('analyzeVideo failed', { jobId, err: err.message });
      jobs[jobId].status = 'failed';
      jobs[jobId].error = err.message;
    });

  logger.info('Job queued', { jobId, url });
  res.json({ jobId });
});

/**
 * GET /api/video/jobs/:jobId
 * Returns full job state: { status, progress, clips, error }
 */
router.get('/jobs/:jobId', (req, res) => {
  const job = jobs[req.params.jobId];
  if (!job) return res.status(404).json({ error: 'Job not found' });
  res.json(job);
});

module.exports = router;
module.exports.jobs = jobs;
