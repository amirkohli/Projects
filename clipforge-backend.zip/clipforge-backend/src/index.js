require('dotenv').config();
const express = require('express');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const { logger } = require('./utils/logger');

const videoRoutes = require('./routes/video');
const clipsRoutes = require('./routes/clips');
const uploadRoutes = require('./routes/upload');
const authRoutes = require('./routes/auth');

const app = express();
const PORT = process.env.PORT || 3000;

// ── Middleware ─────────────────────────────────────────────
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve generated clips statically
app.use('/clips', express.static(process.env.CLIPS_DIR || './clips'));

// Rate limiting
const limiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 50 });
app.use('/api/', limiter);

// ── Routes ────────────────────────────────────────────────
app.use('/api/video', videoRoutes);     // POST /api/video/analyze
app.use('/api/clips', clipsRoutes);     // GET  /api/clips/:jobId
app.use('/api/upload', uploadRoutes);   // POST /api/upload/:platform
app.use('/auth', authRoutes);           // OAuth callbacks

// ── Health check ──────────────────────────────────────────
app.get('/health', (req, res) => res.json({ status: 'ok', version: '1.0.0' }));

// ── Global error handler ──────────────────────────────────
app.use((err, req, res, next) => {
  logger.error(err.message, { stack: err.stack });
  res.status(err.status || 500).json({ error: err.message || 'Internal server error' });
});

app.listen(PORT, () => logger.info(`ClipForge backend running on http://localhost:${PORT}`));
module.exports = app;
