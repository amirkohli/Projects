/**
 * Simple API key middleware.
 * Set API_KEY in .env and pass it as x-api-key header from your frontend.
 * Swap for JWT/session auth in production.
 */
function requireApiKey(req, res, next) {
  const key = req.headers['x-api-key'];
  if (!process.env.API_KEY || key === process.env.API_KEY) return next();
  return res.status(401).json({ error: 'Unauthorized' });
}

module.exports = { requireApiKey };
