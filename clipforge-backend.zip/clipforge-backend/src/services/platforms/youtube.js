const fs = require('fs');
const { google } = require('googleapis');
const { logger } = require('../../utils/logger');

/**
 * Upload a clip to YouTube as a Short.
 * Requires: YOUTUBE_CLIENT_ID, YOUTUBE_CLIENT_SECRET, YOUTUBE_ACCESS_TOKEN (stored after OAuth)
 */
async function upload({ clip, caption, scheduleAt }) {
  const oauth2Client = new google.auth.OAuth2(
    process.env.YOUTUBE_CLIENT_ID,
    process.env.YOUTUBE_CLIENT_SECRET,
    process.env.YOUTUBE_REDIRECT_URI
  );

  // In production, load tokens from DB per-user
  oauth2Client.setCredentials({
    access_token: process.env.YOUTUBE_ACCESS_TOKEN,
    refresh_token: process.env.YOUTUBE_REFRESH_TOKEN,
  });

  const youtube = google.youtube({ version: 'v3', auth: oauth2Client });

  const tags = extractHashtags(caption).concat(['Shorts']);

  const requestBody = {
    snippet: {
      title: clip.title.slice(0, 100),
      description: caption,
      tags,
      categoryId: '22', // People & Blogs
    },
    status: {
      privacyStatus: scheduleAt ? 'private' : 'public',
      selfDeclaredMadeForKids: false,
      ...(scheduleAt && { publishAt: new Date(scheduleAt).toISOString() }),
    },
  };

  const media = {
    mimeType: 'video/mp4',
    body: fs.createReadStream(clip.filePath),
  };

  logger.info('Uploading to YouTube Shorts', { title: clip.title });

  const response = await youtube.videos.insert({
    part: ['snippet', 'status'],
    requestBody,
    media,
  });

  const videoId = response.data.id;
  return {
    postId: videoId,
    url: `https://www.youtube.com/shorts/${videoId}`,
  };
}

function extractHashtags(text) {
  return (text.match(/#\w+/g) || []).map(t => t.slice(1));
}

module.exports = { upload };
