const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const { logger } = require('../../utils/logger');

const BASE = 'https://graph.facebook.com/v18.0';

/**
 * Upload a clip as an Instagram Reel (two-step: create container → publish).
 * Requires: INSTAGRAM_ACCESS_TOKEN, INSTAGRAM_USER_ID
 *
 * Note: Instagram requires a publicly accessible video URL.
 * In production, upload the file to S3/CDN first and pass the public URL.
 */
async function upload({ clip, caption }) {
  const token  = process.env.INSTAGRAM_ACCESS_TOKEN;
  const userId = process.env.INSTAGRAM_USER_ID;

  if (!token || !userId) throw new Error('Instagram credentials not configured');

  // Step 1 – Create media container
  logger.info('Creating Instagram Reel container', { title: clip.title });

  const containerRes = await axios.post(`${BASE}/${userId}/media`, {
    media_type: 'REELS',
    video_url: buildPublicUrl(clip.fileUrl), // Must be public HTTPS URL
    caption: caption.slice(0, 2200),
    share_to_feed: true,
    access_token: token,
  });

  const containerId = containerRes.data.id;

  // Step 2 – Poll until container status is FINISHED
  await waitForContainer(userId, containerId, token);

  // Step 3 – Publish
  logger.info('Publishing Instagram Reel', { containerId });

  const publishRes = await axios.post(`${BASE}/${userId}/media_publish`, {
    creation_id: containerId,
    access_token: token,
  });

  const mediaId = publishRes.data.id;
  return {
    postId: mediaId,
    url: `https://www.instagram.com/p/${mediaId}/`,
  };
}

async function waitForContainer(userId, containerId, token, retries = 10) {
  for (let i = 0; i < retries; i++) {
    await sleep(3000);
    const { data } = await axios.get(`${BASE}/${containerId}`, {
      params: { fields: 'status_code', access_token: token },
    });
    if (data.status_code === 'FINISHED') return;
    if (data.status_code === 'ERROR') throw new Error('Instagram container processing failed');
  }
  throw new Error('Instagram container timed out');
}

function buildPublicUrl(relativeUrl) {
  const base = process.env.PUBLIC_BASE_URL || 'https://your-server.com';
  return `${base}${relativeUrl}`;
}

const sleep = ms => new Promise(r => setTimeout(r, ms));

module.exports = { upload };
