const axios = require('axios');
const { logger } = require('../../utils/logger');

const BASE = 'https://graph.facebook.com/v18.0';

/**
 * Upload a clip as a Facebook Reel.
 * Requires: FACEBOOK_ACCESS_TOKEN, FACEBOOK_PAGE_ID
 */
async function upload({ clip, caption, scheduleAt }) {
  const token  = process.env.FACEBOOK_ACCESS_TOKEN;
  const pageId = process.env.FACEBOOK_PAGE_ID;

  if (!token || !pageId) throw new Error('Facebook credentials not configured');

  const videoUrl = buildPublicUrl(clip.fileUrl);

  logger.info('Uploading Facebook Reel', { title: clip.title });

  // Step 1 – Initialize upload session
  const initRes = await axios.post(`${BASE}/${pageId}/video_reels`, {
    upload_phase: 'start',
    access_token: token,
  });

  const { video_id: videoId, upload_url: uploadUrl } = initRes.data;

  // Step 2 – Transfer video from public URL
  await axios.post(`${BASE}/${pageId}/video_reels`, {
    upload_phase: 'transfer',
    video_id: videoId,
    video_file_chunk: videoUrl,
    access_token: token,
  });

  // Step 3 – Finish & publish
  const publishBody = {
    upload_phase: 'finish',
    video_id: videoId,
    video_state: scheduleAt ? 'SCHEDULED' : 'PUBLISHED',
    description: caption.slice(0, 2200),
    access_token: token,
  };

  if (scheduleAt) {
    publishBody.scheduled_publish_time = Math.floor(new Date(scheduleAt).getTime() / 1000);
  }

  await axios.post(`${BASE}/${pageId}/video_reels`, publishBody);

  logger.info('Facebook Reel published', { videoId });

  return {
    postId: videoId,
    url: `https://www.facebook.com/reel/${videoId}`,
  };
}

function buildPublicUrl(relativeUrl) {
  const base = process.env.PUBLIC_BASE_URL || 'https://your-server.com';
  return `${base}${relativeUrl}`;
}

module.exports = { upload };
