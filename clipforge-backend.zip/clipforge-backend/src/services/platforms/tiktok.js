const fs = require('fs');
const axios = require('axios');
const { logger } = require('../../utils/logger');

/**
 * Upload a clip to TikTok using the TikTok Content Posting API.
 * Requires: TIKTOK_ACCESS_TOKEN
 * Docs: https://developers.tiktok.com/doc/content-posting-api-reference-upload-video
 */
async function upload({ clip, caption }) {
  const token = process.env.TIKTOK_ACCESS_TOKEN;
  if (!token) throw new Error('TikTok access token not configured');

  const fileSize = fs.statSync(clip.filePath).size;

  logger.info('Initiating TikTok upload', { title: clip.title });

  // Step 1 – Initialize upload
  const initRes = await axios.post(
    'https://open.tiktokapis.com/v2/post/publish/video/init/',
    {
      post_info: {
        title: caption.slice(0, 150),
        privacy_level: 'PUBLIC_TO_EVERYONE',
        disable_duet: false,
        disable_comment: false,
        disable_stitch: false,
        video_cover_timestamp_ms: 1000,
      },
      source_info: {
        source: 'FILE_UPLOAD',
        video_size: fileSize,
        chunk_size: fileSize,
        total_chunk_count: 1,
      },
    },
    {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json; charset=UTF-8',
      },
    }
  );

  const { upload_url, publish_id } = initRes.data.data;

  // Step 2 – Upload binary
  const videoBuffer = fs.readFileSync(clip.filePath);

  await axios.put(upload_url, videoBuffer, {
    headers: {
      'Content-Type': 'video/mp4',
      'Content-Range': `bytes 0-${fileSize - 1}/${fileSize}`,
      'Content-Length': fileSize,
    },
  });

  // Step 3 – Poll publish status
  const postId = await pollPublishStatus(publish_id, token);

  logger.info('TikTok upload complete', { publishId: publish_id });

  return {
    postId: publish_id,
    url: `https://www.tiktok.com/@me/video/${postId}`,
  };
}

async function pollPublishStatus(publishId, token, retries = 12) {
  for (let i = 0; i < retries; i++) {
    await sleep(5000);
    const { data } = await axios.post(
      'https://open.tiktokapis.com/v2/post/publish/status/fetch/',
      { publish_id: publishId },
      { headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' } }
    );
    const { status, publicaly_available_post_id } = data.data;
    if (status === 'PUBLISH_COMPLETE') return publicaly_available_post_id?.[0];
    if (status === 'FAILED') throw new Error('TikTok publish failed');
  }
  throw new Error('TikTok publish timed out');
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
module.exports = { upload };
