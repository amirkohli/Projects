const fs = require('fs');
const axios = require('axios');
const { logger } = require('../../utils/logger');

/**
 * Upload a clip to LinkedIn as a video post.
 * Requires: LINKEDIN_ACCESS_TOKEN
 * Docs: https://learn.microsoft.com/en-us/linkedin/marketing/integrations/community-management/shares/video-api
 */
async function upload({ clip, caption }) {
  const token = process.env.LINKEDIN_ACCESS_TOKEN;
  if (!token) throw new Error('LinkedIn access token not configured');

  const headers = {
    Authorization: `Bearer ${token}`,
    'Content-Type': 'application/json',
    'X-Restli-Protocol-Version': '2.0.0',
  };

  // Step 1 – Get author URN (person or organization)
  const meRes = await axios.get('https://api.linkedin.com/v2/me', { headers });
  const authorUrn = `urn:li:person:${meRes.data.id}`;

  logger.info('Registering LinkedIn video upload', { author: authorUrn });

  // Step 2 – Register upload
  const registerRes = await axios.post(
    'https://api.linkedin.com/v2/assets?action=registerUpload',
    {
      registerUploadRequest: {
        recipes: ['urn:li:digitalmediaRecipe:feedshare-video'],
        owner: authorUrn,
        serviceRelationships: [
          { relationshipType: 'OWNER', identifier: 'urn:li:userGeneratedContent' },
        ],
      },
    },
    { headers }
  );

  const uploadUrl = registerRes.data.value.uploadMechanism[
    'com.linkedin.digitalmedia.uploading.MediaUploadHttpRequest'
  ].uploadUrl;
  const assetUrn = registerRes.data.value.asset;

  // Step 3 – Upload binary
  const videoBuffer = fs.readFileSync(clip.filePath);
  await axios.put(uploadUrl, videoBuffer, {
    headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/octet-stream' },
  });

  // Step 4 – Create post
  const postRes = await axios.post(
    'https://api.linkedin.com/v2/ugcPosts',
    {
      author: authorUrn,
      lifecycleState: 'PUBLISHED',
      specificContent: {
        'com.linkedin.ugc.ShareContent': {
          shareCommentary: { text: caption.slice(0, 3000) },
          shareMediaCategory: 'VIDEO',
          media: [
            {
              status: 'READY',
              description: { text: clip.title },
              media: assetUrn,
              title: { text: clip.title.slice(0, 200) },
            },
          ],
        },
      },
      visibility: { 'com.linkedin.ugc.MemberNetworkVisibility': 'PUBLIC' },
    },
    { headers }
  );

  const postId = postRes.data.id;
  logger.info('LinkedIn post published', { postId });

  return {
    postId,
    url: `https://www.linkedin.com/feed/update/${postId}`,
  };
}

module.exports = { upload };
