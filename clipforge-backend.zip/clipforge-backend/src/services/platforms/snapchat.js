const fs = require('fs');
const axios = require('axios');
const FormData = require('form-data');
const { logger } = require('../../utils/logger');

/**
 * Upload a clip to Snapchat Spotlight/Stories via Snap Kit Media API.
 * Requires: SNAPCHAT_ACCESS_TOKEN
 * Docs: https://developers.snap.com/api/content-api
 */
async function upload({ clip, caption }) {
  const token = process.env.SNAPCHAT_ACCESS_TOKEN;
  if (!token) throw new Error('Snapchat access token not configured');

  const headers = { Authorization: `Bearer ${token}` };

  logger.info('Uploading to Snapchat Spotlight', { title: clip.title });

  // Step 1 – Create media upload
  const createRes = await axios.post(
    'https://adsapi.snapchat.com/v1/media',
    { media: [{ name: clip.title, type: 'VIDEO', ad_account_id: process.env.SNAPCHAT_AD_ACCOUNT_ID }] },
    { headers: { ...headers, 'Content-Type': 'application/json' } }
  );

  const mediaId = createRes.data.media[0].media.id;

  // Step 2 – Upload binary
  const form = new FormData();
  form.append('file', fs.createReadStream(clip.filePath), {
    contentType: 'video/mp4',
    filename: `${clip.id}.mp4`,
  });

  await axios.post(
    `https://adsapi.snapchat.com/v1/media/${mediaId}/upload`,
    form,
    { headers: { ...headers, ...form.getHeaders() } }
  );

  // Step 3 – Create Spotlight post (organic content)
  // Note: Snapchat's organic posting API is limited; this uses the Content API
  const storyRes = await axios.post(
    'https://adsapi.snapchat.com/v1/stories',
    {
      stories: [{
        title: clip.title.slice(0, 50),
        description: caption.slice(0, 500),
        media_id: mediaId,
        story_type: 'SPOTLIGHT',
      }],
    },
    { headers: { ...headers, 'Content-Type': 'application/json' } }
  );

  const storyId = storyRes.data.stories?.[0]?.story?.id;
  logger.info('Snapchat post published', { storyId });

  return {
    postId: storyId,
    url: `https://www.snapchat.com/spotlight/${storyId}`,
  };
}

module.exports = { upload };
