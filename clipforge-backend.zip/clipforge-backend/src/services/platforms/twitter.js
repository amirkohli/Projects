const fs = require('fs');
const { TwitterApi } = require('twitter-api-v2');
const { logger } = require('../../utils/logger');

/**
 * Upload a clip to Twitter/X as a video tweet.
 * Requires: TWITTER_API_KEY, TWITTER_API_SECRET,
 *           TWITTER_ACCESS_TOKEN, TWITTER_ACCESS_SECRET
 */
async function upload({ clip, caption }) {
  const client = new TwitterApi({
    appKey: process.env.TWITTER_API_KEY,
    appSecret: process.env.TWITTER_API_SECRET,
    accessToken: process.env.TWITTER_ACCESS_TOKEN,
    accessSecret: process.env.TWITTER_ACCESS_SECRET,
  });

  const rwClient = client.readWrite;

  logger.info('Uploading video to Twitter/X', { title: clip.title });

  // Step 1 – Upload media (chunked upload handled by library)
  const mediaId = await rwClient.v1.uploadMedia(clip.filePath, {
    mimeType: 'video/mp4',
    longVideo: clip.duration > 30,
  });

  // Step 2 – Wait for media processing
  await rwClient.v1.waitForMediaProcessing(mediaId);

  // Step 3 – Post tweet
  const tweet = await rwClient.v2.tweet({
    text: caption.slice(0, 280),
    media: { media_ids: [mediaId] },
  });

  logger.info('Twitter/X post published', { tweetId: tweet.data.id });

  return {
    postId: tweet.data.id,
    url: `https://twitter.com/i/web/status/${tweet.data.id}`,
  };
}

module.exports = { upload };
