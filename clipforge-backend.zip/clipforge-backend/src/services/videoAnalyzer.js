const path = require('path');
const fs = require('fs');
const { execSync, exec } = require('child_process');
const { promisify } = require('util');
const ffmpeg = require('fluent-ffmpeg');
const OpenAI = require('openai');
const { v4: uuidv4 } = require('uuid');
const { logger } = require('../utils/logger');

const execAsync = promisify(exec);
const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const UPLOAD_DIR = process.env.UPLOAD_DIR || './uploads';
const CLIPS_DIR  = process.env.CLIPS_DIR  || './clips';

// Ensure directories exist
[UPLOAD_DIR, CLIPS_DIR].forEach(d => fs.mkdirSync(d, { recursive: true }));

/**
 * Main pipeline:
 * 1. Download video via yt-dlp
 * 2. Transcribe with OpenAI Whisper
 * 3. GPT-4 detects top viral moments
 * 4. FFmpeg cuts each clip + reframes to 9:16
 * 5. Update job state throughout
 */
async function analyzeVideo({ url, clipLength, clipCount, format, jobId, jobs }) {
  const job = jobs[jobId];
  const setProgress = (pct, status) => { job.progress = pct; job.status = status; };

  // ── Step 1: Download ──────────────────────────────────
  setProgress(5, 'downloading');
  logger.info('Downloading video', { url, jobId });

  const videoId  = uuidv4();
  const rawPath  = path.join(UPLOAD_DIR, `${videoId}.mp4`);

  // yt-dlp must be installed: pip install yt-dlp
  await execAsync(
    `yt-dlp -f "bestvideo[ext=mp4]+bestaudio[ext=m4a]/mp4" -o "${rawPath}" "${url}"`
  );

  if (!fs.existsSync(rawPath)) throw new Error('Download failed – file not found');
  setProgress(20, 'transcribing');

  // ── Step 2: Transcribe with Whisper ──────────────────
  logger.info('Transcribing audio', { jobId });
  const audioPath = path.join(UPLOAD_DIR, `${videoId}.mp3`);

  await new Promise((resolve, reject) => {
    ffmpeg(rawPath).noVideo().audioCodec('libmp3lame').save(audioPath)
      .on('end', resolve).on('error', reject);
  });

  const transcription = await openai.audio.transcriptions.create({
    file: fs.createReadStream(audioPath),
    model: 'whisper-1',
    response_format: 'verbose_json',
    timestamp_granularities: ['segment'],
  });

  const segments = transcription.segments; // [{ start, end, text }]
  setProgress(45, 'detecting_moments');

  // ── Step 3: GPT-4 viral moment detection ─────────────
  logger.info('Detecting viral moments', { jobId, segmentCount: segments.length });

  const prompt = `You are a viral social-media clip editor.
Given these transcript segments with timestamps, identify the top ${clipCount} moments most likely to go viral as short clips (~${clipLength}s each).
For each moment return JSON with: startTime (seconds), endTime (seconds), title (≤8 words), reason (1 sentence), viralityScore (0-100).

Segments:
${JSON.stringify(segments.map(s => ({ start: s.start, end: s.end, text: s.text })))}

Respond ONLY with a JSON array, no markdown.`;

  const gptResp = await openai.chat.completions.create({
    model: 'gpt-4',
    messages: [{ role: 'user', content: prompt }],
    temperature: 0.4,
  });

  let moments;
  try {
    moments = JSON.parse(gptResp.choices[0].message.content);
  } catch {
    throw new Error('GPT-4 returned invalid JSON for moments');
  }

  setProgress(65, 'cutting_clips');

  // ── Step 4: Cut clips with FFmpeg ─────────────────────
  logger.info('Cutting clips', { jobId, count: moments.length });

  const [w, h] = format === '9:16' ? [1080, 1920]
               : format === '1:1'  ? [1080, 1080]
               : [1920, 1080];

  const clips = [];

  for (let i = 0; i < moments.length; i++) {
    const m      = moments[i];
    const clipId = `${jobId}_clip${i}`;
    const outPath = path.join(CLIPS_DIR, `${clipId}.mp4`);
    const duration = Math.min(m.endTime - m.startTime, clipLength);

    await new Promise((resolve, reject) => {
      ffmpeg(rawPath)
        .setStartTime(m.startTime)
        .setDuration(duration)
        // Reframe: scale + crop to target aspect ratio, burn subtitle if needed
        .videoFilters([
          `scale=${w * 2}:${h * 2}:force_original_aspect_ratio=increase`,
          `crop=${w}:${h}`,
        ])
        .videoCodec('libx264')
        .outputOptions(['-crf 23', '-preset fast', '-movflags +faststart'])
        .audioCodec('aac')
        .audioBitrate('128k')
        .save(outPath)
        .on('end', resolve)
        .on('error', reject);
    });

    clips.push({
      id: clipId,
      index: i,
      title: m.title,
      reason: m.reason,
      viralityScore: m.viralityScore,
      startTime: m.startTime,
      endTime: m.endTime,
      duration,
      filePath: outPath,
      fileUrl: `/clips/${clipId}.mp4`,
      format,
    });

    setProgress(65 + Math.round(((i + 1) / moments.length) * 30), 'cutting_clips');
  }

  // ── Step 5: Cleanup raw files ─────────────────────────
  [rawPath, audioPath].forEach(f => { try { fs.unlinkSync(f); } catch {} });

  job.clips  = clips;
  job.status = 'done';
  job.progress = 100;
  logger.info('Analysis complete', { jobId, clips: clips.length });
}

module.exports = { analyzeVideo };
