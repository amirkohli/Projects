# ClipForge Backend

AI-powered video-to-clips automation with upload to **7 social media platforms**.

## Architecture

```
Video URL  →  yt-dlp download  →  Whisper transcription
           →  GPT-4 moment detection  →  FFmpeg clip cutting
           →  Upload to YouTube / Instagram / Facebook / TikTok / Twitter / LinkedIn / Snapchat
```

---

## Prerequisites

| Tool | Install |
|------|---------|
| Node.js 18+ | https://nodejs.org |
| FFmpeg | `brew install ffmpeg` / `apt install ffmpeg` |
| yt-dlp | `pip install yt-dlp` |

---

## Quick start

```bash
# 1. Clone and install
git clone <repo>
cd clipforge-backend
npm install

# 2. Configure environment
cp .env.example .env
# Fill in all credentials (see Platform Setup below)

# 3. Run
npm run dev        # development (nodemon)
npm start          # production
```

---

## API Reference

### Analyze a video
```
POST /api/video/analyze
Content-Type: application/json

{
  "url": "https://youtube.com/watch?v=...",
  "clipLength": 60,
  "clipCount": 5,
  "format": "9:16"
}

→ { "jobId": "uuid" }
```

### Poll job status
```
GET /api/video/jobs/:jobId

→ {
    "status": "cutting_clips",   // queued|downloading|transcribing|detecting_moments|cutting_clips|done|failed
    "progress": 72,
    "clips": [...],
    "error": null
  }
```

### Upload one clip to a platform
```
POST /api/upload/:platform
# platform: youtube | instagram | facebook | tiktok | twitter | linkedin | snapchat

{
  "jobId": "uuid",
  "clipIndex": 0,
  "caption": "This moment changed everything #viral",
  "scheduleAt": "2025-01-15T10:00:00Z"   // optional ISO timestamp
}

→ { "success": true, "platform": "youtube", "postId": "...", "url": "..." }
```

### Upload one clip to multiple platforms at once
```
POST /api/upload/bulk/all

{
  "jobId": "uuid",
  "clipIndex": 0,
  "platforms": ["youtube", "tiktok", "instagram"],
  "caption": "Check this out! #viral"
}

→ { "results": [{ "platform": "youtube", "success": true, "url": "..." }, ...] }
```

### Download a clip
```
GET /api/clips/:jobId/:clipIndex/download
```

---

## Platform Setup

### YouTube Shorts
1. Go to [Google Cloud Console](https://console.cloud.google.com)
2. Create a project → Enable **YouTube Data API v3**
3. Create OAuth 2.0 credentials (Web application)
4. Add `http://localhost:3000/auth/youtube/callback` as redirect URI
5. Visit `http://localhost:3000/auth/youtube` to authorize
6. Copy the returned tokens to `.env`

### Instagram Reels
1. Go to [Meta for Developers](https://developers.facebook.com)
2. Create an app → Add **Instagram Graph API** product
3. Get a long-lived access token via `http://localhost:3000/auth/meta`
4. Set `INSTAGRAM_USER_ID` (your IG business account ID)
5. **Note:** Instagram requires a public HTTPS video URL. Set `PUBLIC_BASE_URL` to your server's public URL (e.g. use [ngrok](https://ngrok.com) for local dev)

### Facebook Reels
- Same Meta app as Instagram
- Set `FACEBOOK_PAGE_ID` (your Facebook Page ID)
- Use the same long-lived page access token

### TikTok
1. Go to [TikTok for Developers](https://developers.tiktok.com)
2. Create an app → Request **Content Posting API** access
3. Set `TIKTOK_CLIENT_KEY` and `TIKTOK_CLIENT_SECRET`
4. Visit `http://localhost:3000/auth/tiktok` to authorize

### Twitter / X
1. Go to [developer.twitter.com](https://developer.twitter.com)
2. Create a project and app with **Read and Write** permissions
3. Enable OAuth 2.0
4. Set all 4 Twitter credentials in `.env`

### LinkedIn
1. Go to [LinkedIn Developer Portal](https://developer.linkedin.com)
2. Create an app → Request **Share on LinkedIn** and **Video Upload** products
3. Set `LINKEDIN_CLIENT_ID` and `LINKEDIN_CLIENT_SECRET`
4. Visit `http://localhost:3000/auth/linkedin` to authorize

### Snapchat
1. Go to [Snap Kit Developer Portal](https://kit.snapchat.com)
2. Create an app → Enable **Content API**
3. Set `SNAPCHAT_CLIENT_ID`, `SNAPCHAT_CLIENT_SECRET`, and `SNAPCHAT_AD_ACCOUNT_ID`
4. Visit `http://localhost:3000/auth/snapchat` to authorize

---

## Environment variables

See `.env.example` for the complete list with descriptions.

---

## Project structure

```
src/
├── index.js                    # Express app entry point
├── routes/
│   ├── auth.js                 # OAuth2 flows for all 7 platforms
│   ├── video.js                # POST /api/video/analyze + job polling
│   ├── clips.js                # GET clip list + download
│   └── upload.js               # POST upload to platform(s)
├── services/
│   ├── videoAnalyzer.js        # yt-dlp + Whisper + GPT-4 + FFmpeg pipeline
│   └── platforms/
│       ├── youtube.js
│       ├── instagram.js
│       ├── facebook.js
│       ├── tiktok.js
│       ├── twitter.js
│       ├── linkedin.js
│       └── snapchat.js
├── middleware/
│   └── auth.js                 # API key guard
└── utils/
    └── logger.js               # Winston logger
```

---

## Production checklist

- [ ] Replace in-memory job store with Redis (use [bull](https://www.npmjs.com/package/bull) for queues)
- [ ] Store OAuth tokens in a database (PostgreSQL/MongoDB) per user
- [ ] Upload clip files to S3/R2 (Instagram & Facebook require public HTTPS URLs)
- [ ] Set `PUBLIC_BASE_URL` to your production domain
- [ ] Add user authentication (JWT or sessions)
- [ ] Set `NODE_ENV=production`
- [ ] Use PM2 or Docker for process management
